CMPT 135 Final Project
======================

Names of Team Members
---------------------

Jerry Chen
jerry_chen_14@sfu.ca
id: 301539072

Adam Wu
yutongwu0805@gmail.com (currently at a swim meet
 and doesn't have his PC which has his SFU email on)
301539206


Instructions for Compiling and Running
--------------------------------------

in the shell type:
make

then
./a5_main_test


Limitations
-----------

List: if an invalid input is entered when selecting options, it doesn't prompt the user to enter a valid input

Search and delete are case sensitive

did not implement ncurses

Known Bugs
----------

N/A


Extra Features
--------------

N/A