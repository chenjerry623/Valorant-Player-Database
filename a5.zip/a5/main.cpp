
#include "Menu.h"

#include <assert.h>

using namespace std;

int main()
{
    Menu test;

    return 0;
}